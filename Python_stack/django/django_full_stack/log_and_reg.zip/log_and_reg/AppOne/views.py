from django.shortcuts import render, redirect
from django.contrib import messages
import bcrypt
from .models import *

def index(request):
    
    return render(request, "index.html")

def add_user(request):
    errors = User.objects.user_validator(request.POST)

    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value, extra_tags=key)
        return redirect("/")

    password = request.POST['password']
    pw_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
    print(pw_hash)
    confpw = request.POST['confpw']
    confpw_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
    print(confpw_hash)

    new_user = User.objects.create(
        first_name = request.POST['first_name'],
        last_name = request.POST['last_name'],
        email = request.POST['email'],
        password = pw_hash,
        confpw = confpw_hash
    )
    return redirect("/success")

def login(request):
    if request.method == 'POST':

        user = User.objects.filter(email=request.POST['email'].lower())
        if user:
            logged_user = user[0]
            if bcrypt.checkpw(request.POST['password'].encode(), logged_user.password.encode()):
                request.session['userid'] = logged_user.id
                return redirect('/success')
        messages.error(request, "Invalid login credentials", extra_tags="login")
    return redirect("/")

def logged_in(request):
    context = {
        "list_of_users": User.objects.all()
    }

    return render(request, "logged_in.html", context)

def logout(request):
    request.session.flush()
    return redirect('/')
# Create your views here.