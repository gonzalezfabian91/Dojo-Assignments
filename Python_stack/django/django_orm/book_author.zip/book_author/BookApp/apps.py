from django.apps import AppConfig


class BookappConfig(AppConfig):
    name = 'BookApp'
